-- ============================================================
-- CampusCare – Smart Campus Service Management System
-- Schema v2  (compatible with Spring Boot ddl-auto=update)
-- Run ONCE in MySQL before first startup:
--   mysql -u root -p < schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS smart_campus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_campus;

-- ── Departments ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS departments (
  id   BIGINT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE
);

-- ── Categories ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
  id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
  name                  VARCHAR(100) NOT NULL UNIQUE,
  default_department_id BIGINT NULL,
  CONSTRAINT fk_cat_dept FOREIGN KEY (default_department_id) REFERENCES departments(id)
);

-- ── Users ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  role          VARCHAR(20)  NOT NULL,   -- STUDENT, STAFF, TECHNICIAN, DEPT_HEAD, ADMIN
  department_id BIGINT NULL,
  CONSTRAINT fk_user_dept FOREIGN KEY (department_id) REFERENCES departments(id)
);

-- ── Service Requests ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS service_requests (
  id                      BIGINT AUTO_INCREMENT PRIMARY KEY,
  title                   VARCHAR(200) NOT NULL,
  description             TEXT NOT NULL,
  location                VARCHAR(200),
  building                VARCHAR(100),
  floor                   VARCHAR(50),
  room_number             VARCHAR(50),
  priority                VARCHAR(10)  NOT NULL DEFAULT 'MEDIUM',
  status                  VARCHAR(20)  NOT NULL DEFAULT 'OPEN',
  ai_categorized          BOOLEAN      NOT NULL DEFAULT FALSE,
  requester_id            BIGINT NOT NULL,
  assigned_technician_id  BIGINT NULL,
  category_id             BIGINT NULL,
  department_id           BIGINT NULL,
  created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_req_user  FOREIGN KEY (requester_id)           REFERENCES users(id),
  CONSTRAINT fk_req_tech  FOREIGN KEY (assigned_technician_id) REFERENCES users(id),
  CONSTRAINT fk_req_cat   FOREIGN KEY (category_id)            REFERENCES categories(id),
  CONSTRAINT fk_req_dept  FOREIGN KEY (department_id)          REFERENCES departments(id),
  INDEX idx_req_status    (status),
  INDEX idx_req_requester (requester_id),
  INDEX idx_req_tech      (assigned_technician_id)
);

-- ── Request History / Updates ─────────────────────────────────
CREATE TABLE IF NOT EXISTS request_updates (
  id            BIGINT AUTO_INCREMENT PRIMARY KEY,
  request_id    BIGINT NOT NULL,
  status        VARCHAR(20) NOT NULL,
  comment       VARCHAR(500),
  updated_by_id BIGINT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_upd_req  FOREIGN KEY (request_id)    REFERENCES service_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_upd_user FOREIGN KEY (updated_by_id) REFERENCES users(id)
);

-- ── Feedback ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS feedback (
  id         BIGINT AUTO_INCREMENT PRIMARY KEY,
  request_id BIGINT NOT NULL UNIQUE,
  student_id BIGINT NOT NULL,
  rating     INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comments   TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_fb_req FOREIGN KEY (request_id) REFERENCES service_requests(id) ON DELETE CASCADE,
  CONSTRAINT fk_fb_stu FOREIGN KEY (student_id) REFERENCES users(id)
);

-- ── Chatbot FAQs ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chatbot_faqs (
  id       BIGINT AUTO_INCREMENT PRIMARY KEY,
  question TEXT NOT NULL,
  answer   TEXT NOT NULL,
  keywords TEXT NOT NULL
);
