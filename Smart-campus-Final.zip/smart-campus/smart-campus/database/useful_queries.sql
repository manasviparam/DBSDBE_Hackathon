USE smart_campus;
-- Requests per status
SELECT status, COUNT(*) AS total FROM service_requests GROUP BY status;
-- Requests per category
SELECT c.name, COUNT(r.id) AS total FROM categories c LEFT JOIN service_requests r ON r.category_id=c.id GROUP BY c.name;
-- Full request view
SELECT r.id, r.title, r.status, r.priority, u.name AS requester, c.name AS category, d.name AS department, r.created_at
FROM service_requests r JOIN users u ON u.id=r.requester_id
LEFT JOIN categories c ON c.id=r.category_id LEFT JOIN departments d ON d.id=r.department_id
ORDER BY r.created_at DESC;
-- Average resolution time (hours)
SELECT ROUND(AVG(TIMESTAMPDIFF(HOUR, created_at, updated_at)),1) AS avg_hours
FROM service_requests WHERE status IN ('RESOLVED','CLOSED');
