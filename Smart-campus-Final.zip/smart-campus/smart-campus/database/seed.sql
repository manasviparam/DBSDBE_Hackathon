-- ============================================================
-- CampusCare – Seed Data
-- Passwords are BCrypt-hashed (cost 10):
--   admin@campus.edu  → Admin@123
--   tech@campus.edu   → Tech@123
--   student@campus.edu → Student@123
-- Run AFTER schema.sql has been applied.
-- ============================================================
USE smart_campus;

-- Departments
INSERT IGNORE INTO departments (name) VALUES
  ('Maintenance'),
  ('Electrical'),
  ('Plumbing'),
  ('Housekeeping'),
  ('IT & Network');

-- Categories (linked to departments)
INSERT IGNORE INTO categories (name, default_department_id) VALUES
  ('Maintenance', (SELECT id FROM departments WHERE name='Maintenance')),
  ('Electricity', (SELECT id FROM departments WHERE name='Electrical')),
  ('Plumbing',    (SELECT id FROM departments WHERE name='Plumbing')),
  ('Cleanliness', (SELECT id FROM departments WHERE name='Housekeeping')),
  ('Internet',    (SELECT id FROM departments WHERE name='IT & Network'));

-- Demo Users (BCrypt hashes — change passwords after setup)
-- Admin: admin@campus.edu / Admin@123
INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
  ('Administrator', 'admin@campus.edu',
   '$2a$10$NYFZ/8WaQ3Qb6FCs.00jDOGT9TyfSMnCVXFnRdSn8MXTW7yXjTwBO', 'ADMIN');

-- Technician: tech@campus.edu / Tech@123
INSERT IGNORE INTO users (name, email, password_hash, role, department_id) VALUES
  ('Ravi Kumar', 'tech@campus.edu',
   '$2a$10$GnprjLYrMnQlMBjMoL1UvehLVdYMmL2.l2GvYO5xYGXxS00/6pUHC', 'TECHNICIAN',
   (SELECT id FROM departments WHERE name='Electrical'));

-- Student: student@campus.edu / Student@123
INSERT IGNORE INTO users (name, email, password_hash, role) VALUES
  ('Priya Sharma', 'student@campus.edu',
   '$2a$10$Vj/Fo5Y0JTEi.VGF4FiWluoOg9iH4gC7qv/3m6N8wVZ/JeGl6TtUe', 'STUDENT');

-- Sample requests (only if none exist)
INSERT INTO service_requests
  (title, description, location, building, floor, room_number, priority, status, requester_id, category_id, department_id, created_at, updated_at)
SELECT
  'Fan not working in lab', 'The ceiling fan in Computer Lab 2 has been not working for 3 days.',
  'Block C, 2nd Floor, Room 204', 'Block C', '2nd', '204',
  'HIGH', 'OPEN',
  (SELECT id FROM users WHERE email='student@campus.edu'),
  (SELECT id FROM categories WHERE name='Electricity'),
  (SELECT id FROM departments WHERE name='Electrical'),
  NOW() - INTERVAL 4 DAY, NOW() - INTERVAL 4 DAY
WHERE NOT EXISTS (SELECT 1 FROM service_requests LIMIT 1);

INSERT INTO service_requests
  (title, description, location, building, floor, room_number, priority, status, requester_id, category_id, department_id, assigned_technician_id, created_at, updated_at)
SELECT
  'Water leakage in washroom', 'Continuous water drip from tap in boys washroom.',
  'Block A, Ground Floor', 'Block A', 'Ground', 'Washroom-G1',
  'HIGH', 'ASSIGNED',
  (SELECT id FROM users WHERE email='student@campus.edu'),
  (SELECT id FROM categories WHERE name='Plumbing'),
  (SELECT id FROM departments WHERE name='Plumbing'),
  (SELECT id FROM users WHERE email='tech@campus.edu'),
  NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 1 DAY
WHERE (SELECT COUNT(*) FROM service_requests) < 2;

INSERT INTO service_requests
  (title, description, location, building, floor, room_number, priority, status, requester_id, category_id, department_id, created_at, updated_at)
SELECT
  'Wi-Fi very slow in library', 'Internet connectivity is extremely slow during peak hours (10am–2pm).',
  'Library, 1st Floor', 'Library', '1st', 'Reading Hall',
  'MEDIUM', 'OPEN',
  (SELECT id FROM users WHERE email='student@campus.edu'),
  (SELECT id FROM categories WHERE name='Internet'),
  (SELECT id FROM departments WHERE name='IT & Network'),
  NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 1 DAY
WHERE (SELECT COUNT(*) FROM service_requests) < 3;
