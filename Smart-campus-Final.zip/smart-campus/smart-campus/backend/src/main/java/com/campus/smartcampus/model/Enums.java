package com.campus.smartcampus.model;

public class Enums {
    public enum Role { STUDENT, STAFF, TECHNICIAN, DEPT_HEAD, ADMIN }
    public enum Status { OPEN, ASSIGNED, IN_PROGRESS, RESOLVED, CLOSED }
    public enum Priority { LOW, MEDIUM, HIGH }
}
