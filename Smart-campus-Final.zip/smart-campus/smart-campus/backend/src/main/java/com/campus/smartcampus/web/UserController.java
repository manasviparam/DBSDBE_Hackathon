package com.campus.smartcampus.web;

import com.campus.smartcampus.model.*;
import com.campus.smartcampus.repo.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD')")
public class UserController {

    private final UserRepo users;
    private final DepartmentRepo departments;
    private final PasswordEncoder enc;

    public UserController(UserRepo u, DepartmentRepo d, PasswordEncoder e) {
        users = u; departments = d; enc = e;
    }

    public record CreateStaffReq(String name, String email, String password,
                                  Enums.Role role, Long departmentId) {}

    @GetMapping
    public List<User> listAll() { return users.findAll(); }

    @GetMapping("/role/{role}")
    public List<User> byRole(@PathVariable Enums.Role role) { return users.findByRole(role); }

    @GetMapping("/technicians")
    public List<User> technicians() { return users.findByRole(Enums.Role.TECHNICIAN); }

    @PostMapping
    public User createStaff(@RequestBody CreateStaffReq in) {
        if (users.findByEmail(in.email()).isPresent())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        // Only allow ADMIN to create ADMIN; others can create STAFF/TECHNICIAN/DEPT_HEAD
        if (in.role() == null || in.role() == Enums.Role.STUDENT) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid role for staff creation");
        }
        User u = new User();
        u.setName(in.name());
        u.setEmail(in.email());
        u.setPasswordHash(enc.encode(in.password()));
        u.setRole(in.role());
        if (in.departmentId() != null) {
            u.setDepartment(departments.findById(in.departmentId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found")));
        }
        return users.save(u);
    }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        User u = users.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        if (body.containsKey("name")) u.setName(body.get("name").toString());
        if (body.containsKey("role")) u.setRole(Enums.Role.valueOf(body.get("role").toString()));
        if (body.containsKey("password") && body.get("password") != null
                && !body.get("password").toString().isBlank()) {
            u.setPasswordHash(enc.encode(body.get("password").toString()));
        }
        if (body.containsKey("departmentId") && body.get("departmentId") != null) {
            Long dId = Long.parseLong(body.get("departmentId").toString());
            u.setDepartment(departments.findById(dId).orElse(null));
        }
        return users.save(u);
    }

    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id) {
        users.deleteById(id);
        return Map.of("message", "User deleted");
    }
}
