package com.campus.smartcampus.web;

import com.campus.smartcampus.model.*;
import com.campus.smartcampus.repo.*;
import com.campus.smartcampus.service.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

@RestController
@RequestMapping("/api")
public class RequestController {

    private final RequestService svc;
    private final RequestRepo repo;
    private final CategoryRepo categories;
    private final DepartmentRepo departments;
    private final ClassifierService classifier;

    public RequestController(RequestService s, RequestRepo r, CategoryRepo c,
                             DepartmentRepo d, ClassifierService cl) {
        svc = s; repo = r; categories = c; departments = d; classifier = cl;
    }

    // ──────── Records ────────
    public record StatusReq(Enums.Status status, String comment) {}
    public record AssignDeptReq(Long departmentId) {}
    public record SuggestReq(String text) {}

    // ──────── Lookup endpoints ────────
    @GetMapping("/categories")
    public List<Category> listCategories() { return categories.findAll(); }

    @GetMapping("/departments")
    public List<Department> listDepartments() { return departments.findAll(); }

    // ──────── Request CRUD ────────
    @PostMapping("/requests")
    public ServiceRequest create(@RequestBody RequestService.CreateReq in, Authentication auth) {
        // Ensure userId matches authenticated user (students can only create for themselves)
        Long actorId = (Long) auth.getPrincipal();
        String role = auth.getAuthorities().iterator().next().getAuthority();
        // Admins/staff can create on behalf of others; students must use their own id
        if (role.equals("ROLE_STUDENT") && !actorId.equals(in.userId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Cannot create request for another user");
        }
        return svc.create(in);
    }

    /**
     * GET /api/requests                 → admin: all requests
     * GET /api/requests?userId=5       → student: own requests
     * GET /api/requests?techId=3       → technician: assigned requests
     */
    @GetMapping("/requests")
    public List<ServiceRequest> list(
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long techId,
            Authentication auth) {
        Long actorId = (Long) auth.getPrincipal();
        String role = auth.getAuthorities().iterator().next().getAuthority();

        if (role.equals("ROLE_STUDENT")) {
            // Students see only their own requests
            return repo.findByRequesterIdOrderByCreatedAtDesc(actorId);
        }
        if (role.equals("ROLE_TECHNICIAN")) {
            return repo.findByAssignedTechnicianIdOrderByCreatedAtDesc(actorId);
        }
        // Admin/Staff/DeptHead
        if (userId != null) return repo.findByRequesterIdOrderByCreatedAtDesc(userId);
        if (techId  != null) return repo.findByAssignedTechnicianIdOrderByCreatedAtDesc(techId);
        return repo.findAllByOrderByCreatedAtDesc();
    }

    @GetMapping("/requests/{id}")
    public ServiceRequest get(@PathVariable Long id, Authentication auth) {
        ServiceRequest r = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Request not found"));
        Long actorId = (Long) auth.getPrincipal();
        String role = auth.getAuthorities().iterator().next().getAuthority();
        // Access control
        if (role.equals("ROLE_STUDENT") && !r.getRequester().getId().equals(actorId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        if (role.equals("ROLE_TECHNICIAN") &&
                (r.getAssignedTechnician() == null || !r.getAssignedTechnician().getId().equals(actorId))) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        }
        return r;
    }

    @GetMapping("/requests/{id}/history")
    public List<RequestUpdate> history(@PathVariable Long id) { return svc.history(id); }

    @PutMapping("/requests/{id}/status")
    public ServiceRequest status(@PathVariable Long id, @RequestBody StatusReq in, Authentication auth) {
        Long actorId = (Long) auth.getPrincipal();
        return svc.changeStatus(id, in.status(), in.comment(), actorId);
    }

    @PutMapping("/requests/{id}/assign-department")
    @PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD','STAFF')")
    public ServiceRequest assignDepartment(@PathVariable Long id, @RequestBody AssignDeptReq in, Authentication auth) {
        Long actorId = (Long) auth.getPrincipal();
        return svc.assignDepartment(id, in.departmentId(), actorId);
    }

    /** Kept for backward-compat with old frontend */
    @PutMapping("/requests/{id}/assign")
    @PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD','STAFF')")
    public ServiceRequest assignLegacy(@PathVariable Long id, @RequestBody AssignDeptReq in, Authentication auth) {
        Long actorId = (Long) auth.getPrincipal();
        return svc.assignDepartment(id, in.departmentId(), actorId);
    }

    @PutMapping("/requests/{id}/assign-technician")
    @PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD','STAFF')")
    public ServiceRequest assignTechnician(@PathVariable Long id,
            @RequestBody RequestService.AssignTechnicianReq in, Authentication auth) {
        Long actorId = (Long) auth.getPrincipal();
        // inject actorId
        return svc.assignTechnician(id, new RequestService.AssignTechnicianReq(in.technicianId(), actorId));
    }

    @PostMapping("/requests/suggest-category")
    public Map<String, String> suggest(@RequestBody SuggestReq in) {
        return Map.of("category", classifier.suggest(in.text()).orElse(""));
    }

    // ──────── Feedback ────────
    @PostMapping("/requests/{id}/feedback")
    public Feedback submitFeedback(@PathVariable Long id,
            @RequestBody Map<String, Object> body, Authentication auth) {
        Long actorId = (Long) auth.getPrincipal();
        int rating = Integer.parseInt(body.get("rating").toString());
        String comments = body.containsKey("comments") ? body.get("comments").toString() : "";
        return svc.submitFeedback(new RequestService.FeedbackReq(id, actorId, rating, comments));
    }

    @GetMapping("/requests/{id}/feedback")
    public Optional<Feedback> getFeedback(@PathVariable Long id) {
        return svc.getFeedback(id);
    }

    // ──────── Admin stats ────────
    @GetMapping("/admin/stats")
    @PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD','STAFF')")
    public Map<String, Object> stats() { return svc.stats(); }

    @GetMapping("/admin/overdue")
    @PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD','STAFF')")
    public List<ServiceRequest> overdue() { return svc.getOverdue(); }
}
