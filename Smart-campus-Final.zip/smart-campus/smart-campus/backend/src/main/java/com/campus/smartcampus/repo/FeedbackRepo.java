package com.campus.smartcampus.repo;

import com.campus.smartcampus.model.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface FeedbackRepo extends JpaRepository<Feedback, Long> {
    @Query("select f from Feedback f where f.request.id = :requestId")
    Optional<Feedback> findByRequestId(@Param("requestId") Long requestId);

    @Query("select count(f) > 0 from Feedback f where f.request.id = :requestId")
    boolean existsByRequestId(@Param("requestId") Long requestId);
}
