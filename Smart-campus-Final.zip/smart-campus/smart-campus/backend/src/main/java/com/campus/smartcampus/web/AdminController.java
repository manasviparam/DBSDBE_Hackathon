package com.campus.smartcampus.web;

import com.campus.smartcampus.model.*;
import com.campus.smartcampus.repo.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasAnyRole('ADMIN','DEPT_HEAD')")
public class AdminController {

    private final DepartmentRepo departments;
    private final CategoryRepo categories;

    public AdminController(DepartmentRepo d, CategoryRepo c) {
        departments = d; categories = c;
    }

    // ──────── Departments ────────
    @PostMapping("/departments")
    public Department createDepartment(@RequestBody Map<String, String> body) {
        Department d = new Department();
        d.setName(body.get("name"));
        return departments.save(d);
    }

    @PutMapping("/departments/{id}")
    public Department updateDepartment(@PathVariable Long id, @RequestBody Map<String, String> body) {
        Department d = departments.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Department not found"));
        d.setName(body.get("name"));
        return departments.save(d);
    }

    @DeleteMapping("/departments/{id}")
    public Map<String, String> deleteDepartment(@PathVariable Long id) {
        departments.deleteById(id);
        return Map.of("message", "Department deleted");
    }

    // ──────── Categories ────────
    public record CategoryReq(String name, Long defaultDepartmentId) {}

    @PostMapping("/categories")
    public Category createCategory(@RequestBody CategoryReq in) {
        Category c = new Category();
        c.setName(in.name());
        if (in.defaultDepartmentId() != null) {
            c.setDefaultDepartment(departments.findById(in.defaultDepartmentId()).orElse(null));
        }
        return categories.save(c);
    }

    @PutMapping("/categories/{id}")
    public Category updateCategory(@PathVariable Long id, @RequestBody CategoryReq in) {
        Category c = categories.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Category not found"));
        c.setName(in.name());
        if (in.defaultDepartmentId() != null) {
            c.setDefaultDepartment(departments.findById(in.defaultDepartmentId()).orElse(null));
        }
        return categories.save(c);
    }

    @DeleteMapping("/categories/{id}")
    public Map<String, String> deleteCategory(@PathVariable Long id) {
        categories.deleteById(id);
        return Map.of("message", "Category deleted");
    }
}
