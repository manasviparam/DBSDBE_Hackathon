package com.campus.smartcampus.service;

import org.springframework.stereotype.Service;
import java.util.*;

/**
 * "AI" categorization. Starts as a keyword-scoring classifier (works offline, no API key).
 * To upgrade: replace suggest() with a call to an LLM API or an ML model and keep the same signature.
 */
@Service
public class ClassifierService {
    private static final Map<String, List<String>> KEYWORDS = new LinkedHashMap<>();
    static {
        KEYWORDS.put("Electricity", List.of("light", "fan", "power", "electric", "switch", "socket", "wire", "bulb", "ac ", "tube", "short circuit", "current"));
        KEYWORDS.put("Plumbing",    List.of("water", "leak", "tap", "pipe", "drain", "toilet", "flush", "washroom", "bathroom", "tank", "overflow"));
        KEYWORDS.put("Cleanliness", List.of("dirty", "clean", "garbage", "dustbin", "trash", "smell", "sweep", "mop", "waste", "hygiene"));
        KEYWORDS.put("Internet",    List.of("wifi", "wi-fi", "internet", "network", "lan", "router", "connection", "bandwidth", "slow net"));
        KEYWORDS.put("Maintenance", List.of("broken", "door", "window", "bench", "desk", "chair", "paint", "crack", "furniture", "lock", "ceiling"));
    }

    /** @return best matching category name, or empty if nothing matches */
    public Optional<String> suggest(String text) {
        String t = (" " + text + " ").toLowerCase();
        String best = null; int bestScore = 0;
        for (var e : KEYWORDS.entrySet()) {
            int score = 0;
            for (String k : e.getValue()) if (t.contains(k)) score++;
            if (score > bestScore) { bestScore = score; best = e.getKey(); }
        }
        return Optional.ofNullable(best);
    }
}
