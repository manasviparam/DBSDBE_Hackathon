package com.campus.smartcampus.repo;

import com.campus.smartcampus.model.Enums;
import com.campus.smartcampus.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByRole(Enums.Role role);

    @Query("select u from User u where u.department.id = :deptId")
    List<User> findByDepartmentId(@Param("deptId") Long deptId);
}
