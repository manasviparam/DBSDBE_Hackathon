package com.campus.smartcampus.config;

import com.campus.smartcampus.model.*;
import com.campus.smartcampus.repo.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AppConfig {

    /** Creates or updates demo accounts on first run with guaranteed working BCrypt passwords. */
    @Bean
    CommandLineRunner seedData(UserRepo users, ChatbotFaqRepo faqs,
                               PasswordEncoder enc,
                               @Value("${app.admin.email}") String email,
                               @Value("${app.admin.password}") String pw) {
        return args -> {
            // Seed / update all demo accounts with guaranteed working BCrypt passwords
            seedUser(users, enc, email, "Administrator", pw, Enums.Role.ADMIN);
            seedUser(users, enc, "tech@campus.edu", "Ravi Kumar", "Tech@123", Enums.Role.TECHNICIAN);
            seedUser(users, enc, "student@campus.edu", "Priya Sharma", "Student@123", Enums.Role.STUDENT);

            // Seed chatbot FAQs if empty
            if (faqs.count() == 0) {
                seedFaq(faqs, "How do I raise a complaint?",
                    "To raise a complaint: Log in as a student, click 'New Request', fill in the title, description, location details (building, floor, room), select a category and priority, then click Submit.",
                    "raise,complaint,submit,request,new,issue,problem");
                seedFaq(faqs, "How do I track my request?",
                    "After logging in, go to 'My Requests'. You can see the current status (Open, Assigned, In Progress, Resolved) and click any request to view its full history and timeline.",
                    "track,status,request,check,follow,progress,update");
                seedFaq(faqs, "How long does resolution take?",
                    "Resolution time depends on the issue type. Electrical and plumbing issues are typically resolved within 24-48 hours. Maintenance issues may take 3-5 working days. High-priority requests are expedited.",
                    "long,time,resolve,resolution,how long,days,hours,duration");
                seedFaq(faqs, "How do I contact campus maintenance?",
                    "You can reach the campus maintenance team by submitting a request through this system, or visit the Maintenance Office at the Administrative Block. For emergencies, call the campus helpdesk at Ext. 1234.",
                    "contact,maintenance,helpdesk,phone,emergency,office,reach");
                seedFaq(faqs, "How do I report Wi-Fi problems?",
                    "Submit a new request and select the 'Internet' category. Describe your issue (e.g., which block/room, speed issues, cannot connect). The IT & Network team will be auto-assigned and respond promptly.",
                    "wifi,wi-fi,internet,network,connection,slow,connect,broadband");
                seedFaq(faqs, "What are the request priority levels?",
                    "Requests have three priority levels: LOW (cosmetic issues, non-urgent), MEDIUM (default - affects daily work), HIGH (urgent - safety or major disruptions). Admins can also adjust priority after submission.",
                    "priority,low,medium,high,urgent,level,important");
                seedFaq(faqs, "Can I cancel or edit my request?",
                    "Once submitted, requests cannot be deleted to maintain audit integrity. However, you can add a comment through the admin or contact the helpdesk to update details. If assigned, only staff can close it.",
                    "cancel,edit,delete,modify,change,request,update");
                System.out.println("[CampusCare] Chatbot FAQs seeded.");
            }
        };
    }

    private void seedUser(UserRepo users, PasswordEncoder enc, String email, String name, String password, Enums.Role role) {
        User u = users.findByEmail(email).orElseGet(User::new);
        u.setEmail(email);
        u.setName(name);
        u.setPasswordHash(enc.encode(password));
        u.setRole(role);
        users.save(u);
        System.out.println("[CampusCare] Configured user: " + email + " with role: " + role);
    }

    private void seedFaq(ChatbotFaqRepo repo, String q, String a, String kw) {
        ChatbotFaq f = new ChatbotFaq();
        f.setQuestion(q); f.setAnswer(a); f.setKeywords(kw);
        repo.save(f);
    }
}
