package com.campus.smartcampus.repo;

import com.campus.smartcampus.model.ServiceRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface RequestRepo extends JpaRepository<ServiceRequest, Long> {
    @Query("select r from ServiceRequest r where r.requester.id = :userId order by r.createdAt desc")
    List<ServiceRequest> findByRequesterIdOrderByCreatedAtDesc(@Param("userId") Long userId);

    @Query("select r from ServiceRequest r where r.assignedTechnician.id = :techId order by r.createdAt desc")
    List<ServiceRequest> findByAssignedTechnicianIdOrderByCreatedAtDesc(@Param("techId") Long techId);

    List<ServiceRequest> findAllByOrderByCreatedAtDesc();

    @Query("select r.status, count(r) from ServiceRequest r group by r.status")
    List<Object[]> countByStatus();

    @Query("select c.name, count(r) from ServiceRequest r join r.category c group by c.name")
    List<Object[]> countByCategory();

    @Query("select r from ServiceRequest r where r.status not in ('RESOLVED','CLOSED') and r.createdAt < :threshold order by r.createdAt asc")
    List<ServiceRequest> findOverdue(@Param("threshold") LocalDateTime threshold);

    @Query("select r from ServiceRequest r where r.department.id = :deptId order by r.createdAt desc")
    List<ServiceRequest> findByDepartmentId(@Param("deptId") Long deptId);
}
