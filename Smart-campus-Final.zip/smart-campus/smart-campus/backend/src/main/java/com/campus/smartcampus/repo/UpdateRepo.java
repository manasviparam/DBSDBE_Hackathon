package com.campus.smartcampus.repo;

import com.campus.smartcampus.model.RequestUpdate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UpdateRepo extends JpaRepository<RequestUpdate, Long> {
    @Query("select u from RequestUpdate u where u.request.id = :requestId order by u.createdAt asc")
    List<RequestUpdate> findByRequestIdOrderByCreatedAtAsc(@Param("requestId") Long requestId);
}
