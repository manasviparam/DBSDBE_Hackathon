package com.campus.smartcampus.repo;

import com.campus.smartcampus.model.ChatbotFaq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChatbotFaqRepo extends JpaRepository<ChatbotFaq, Long> {}
