package com.campus.smartcampus.web;

import com.campus.smartcampus.model.ChatbotFaq;
import com.campus.smartcampus.repo.ChatbotFaqRepo;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/chatbot")
public class ChatbotController {

    private final ChatbotFaqRepo faqs;
    public ChatbotController(ChatbotFaqRepo f) { faqs = f; }

    /** Returns best-matching FAQ answer for a user query using keyword scoring */
    @GetMapping("/ask")
    public Map<String, Object> ask(@RequestParam String q) {
        String query = q.toLowerCase();
        List<ChatbotFaq> all = faqs.findAll();

        ChatbotFaq best = null;
        int bestScore = 0;

        for (ChatbotFaq faq : all) {
            int score = 0;
            for (String kw : faq.getKeywords().split(",")) {
                if (query.contains(kw.trim().toLowerCase())) score++;
            }
            // Also check question words
            for (String word : faq.getQuestion().toLowerCase().split("\\s+")) {
                if (word.length() > 3 && query.contains(word)) score++;
            }
            if (score > bestScore) { bestScore = score; best = faq; }
        }

        if (best != null && bestScore > 0) {
            return Map.of("found", true, "question", best.getQuestion(),
                          "answer", best.getAnswer(), "score", bestScore);
        }
        return Map.of("found", false,
                "answer", "I'm sorry, I don't have an answer for that. Please contact the campus helpdesk or submit a service request.");
    }

    @GetMapping("/faqs")
    public List<ChatbotFaq> listAll() { return faqs.findAll(); }

    @PostMapping("/faqs")
    @PreAuthorize("hasAnyRole('ADMIN')")
    public ChatbotFaq add(@RequestBody ChatbotFaq faq) { return faqs.save(faq); }

    @DeleteMapping("/faqs/{id}")
    @PreAuthorize("hasAnyRole('ADMIN')")
    public Map<String, String> delete(@PathVariable Long id) {
        faqs.deleteById(id);
        return Map.of("message", "FAQ deleted");
    }
}
