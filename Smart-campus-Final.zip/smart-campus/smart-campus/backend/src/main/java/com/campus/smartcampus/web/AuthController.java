package com.campus.smartcampus.web;

import com.campus.smartcampus.model.*;
import com.campus.smartcampus.repo.UserRepo;
import com.campus.smartcampus.security.JwtUtil;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepo users;
    private final PasswordEncoder enc;
    private final JwtUtil jwt;

    public AuthController(UserRepo u, PasswordEncoder e, JwtUtil jwt) {
        users = u; enc = e; this.jwt = jwt;
    }

    public record RegisterReq(String name, String email, String password) {}
    public record LoginReq(String email, String password) {}

    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody RegisterReq in) {
        if (users.findByEmail(in.email()).isPresent())
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already registered");
        User u = new User();
        u.setName(in.name());
        u.setEmail(in.email());
        u.setPasswordHash(enc.encode(in.password()));
        u.setRole(Enums.Role.STUDENT); // Public registration = STUDENT only
        users.save(u);
        String token = jwt.generate(u.getId(), u.getEmail(), u.getRole().name());
        return buildResponse(u, token);
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody LoginReq in) {
        String email = in.email() != null ? in.email().trim() : "";
        String rawPassword = in.password() != null ? in.password().trim() : "";
        User u = users.findByEmail(email)
                .filter(x -> enc.matches(rawPassword, x.getPasswordHash()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid email or password"));
        String token = jwt.generate(u.getId(), u.getEmail(), u.getRole().name());
        return buildResponse(u, token);
    }

    @GetMapping("/me")
    public Map<String, Object> me(org.springframework.security.core.Authentication auth) {
        if (auth == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        Long uid = (Long) auth.getPrincipal();
        User u = users.findById(uid).orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found"));
        return Map.of(
                "id", u.getId(), "name", u.getName(), "email", u.getEmail(),
                "role", u.getRole().name(),
                "departmentId", u.getDepartment() != null ? u.getDepartment().getId() : null,
                "departmentName", u.getDepartment() != null ? u.getDepartment().getName() : null
        );
    }

    private Map<String, Object> buildResponse(User u, String token) {
        return Map.of(
                "token", token,
                "id", u.getId(),
                "name", u.getName(),
                "email", u.getEmail(),
                "role", u.getRole().name(),
                "departmentId", u.getDepartment() != null ? u.getDepartment().getId() : "",
                "departmentName", u.getDepartment() != null ? u.getDepartment().getName() : ""
        );
    }
}
