package com.campus.smartcampus.service;

import com.campus.smartcampus.model.*;
import com.campus.smartcampus.repo.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class RequestService {

    private final RequestRepo requests;
    private final UserRepo users;
    private final CategoryRepo categories;
    private final DepartmentRepo departments;
    private final UpdateRepo updates;
    private final FeedbackRepo feedbacks;
    private final ClassifierService classifier;

    public RequestService(RequestRepo r, UserRepo u, CategoryRepo c, DepartmentRepo d,
                          UpdateRepo up, FeedbackRepo fb, ClassifierService cl) {
        requests = r; users = u; categories = c; departments = d;
        updates = up; feedbacks = fb; classifier = cl;
    }

    // ──────────────────────────── DTOs ────────────────────────────
    public record CreateReq(
            Long userId, String title, String description,
            String location, String building, String floor, String roomNumber,
            Enums.Priority priority, Long categoryId) {}

    public record AssignTechnicianReq(Long technicianId, Long actorId) {}

    public record FeedbackReq(Long requestId, Long studentId, Integer rating, String comments) {}

    // ──────────────────────────── Create ────────────────────────────
    @Transactional
    public ServiceRequest create(CreateReq in) {
        User user = users.findById(in.userId()).orElseThrow(() -> notFound("User"));
        ServiceRequest r = new ServiceRequest();
        r.setTitle(in.title());
        r.setDescription(in.description());
        r.setLocation(in.location());
        r.setBuilding(in.building());
        r.setFloor(in.floor());
        r.setRoomNumber(in.roomNumber());
        if (in.priority() != null) r.setPriority(in.priority());
        r.setRequester(user);

        Category cat;
        if (in.categoryId() != null) {
            cat = categories.findById(in.categoryId()).orElseThrow(() -> notFound("Category"));
        } else {
            cat = classifier.suggest(in.title() + " " + in.description())
                            .flatMap(categories::findByNameIgnoreCase).orElse(null);
            r.setAiCategorized(cat != null);
        }
        r.setCategory(cat);

        if (cat != null && cat.getDefaultDepartment() != null) {
            r.setDepartment(cat.getDefaultDepartment());
            r.setStatus(Enums.Status.ASSIGNED);
        }

        r = requests.save(r);
        log(r, r.getStatus(), "Request submitted", user);
        return r;
    }

    // ──────────────────────────── Status change ────────────────────────────
    @Transactional
    public ServiceRequest changeStatus(Long id, Enums.Status status, String comment, Long actorId) {
        ServiceRequest r = requests.findById(id).orElseThrow(() -> notFound("Request"));
        r.setStatus(status);
        r = requests.save(r);
        User actor = actorId == null ? null : users.findById(actorId).orElse(null);
        log(r, status, comment, actor);
        return r;
    }

    // ──────────────────────────── Assign department ────────────────────────────
    @Transactional
    public ServiceRequest assignDepartment(Long id, Long departmentId, Long actorId) {
        ServiceRequest r = requests.findById(id).orElseThrow(() -> notFound("Request"));
        Department d = departments.findById(departmentId).orElseThrow(() -> notFound("Department"));
        r.setDepartment(d);
        if (r.getStatus() == Enums.Status.OPEN) r.setStatus(Enums.Status.ASSIGNED);
        r = requests.save(r);
        User actor = actorId == null ? null : users.findById(actorId).orElse(null);
        log(r, r.getStatus(), "Assigned to department: " + d.getName(), actor);
        return r;
    }

    // ──────────────────────────── Assign technician ────────────────────────────
    @Transactional
    public ServiceRequest assignTechnician(Long id, AssignTechnicianReq in) {
        ServiceRequest r = requests.findById(id).orElseThrow(() -> notFound("Request"));
        User tech = users.findById(in.technicianId()).orElseThrow(() -> notFound("Technician"));
        if (tech.getRole() != Enums.Role.TECHNICIAN && tech.getRole() != Enums.Role.STAFF) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "User is not a technician/staff");
        }
        r.setAssignedTechnician(tech);
        if (r.getStatus() == Enums.Status.OPEN) r.setStatus(Enums.Status.ASSIGNED);
        r = requests.save(r);
        User actor = in.actorId() == null ? null : users.findById(in.actorId()).orElse(null);
        log(r, r.getStatus(), "Assigned to technician: " + tech.getName(), actor);
        return r;
    }

    // ──────────────────────────── Feedback ────────────────────────────
    @Transactional
    public Feedback submitFeedback(FeedbackReq in) {
        ServiceRequest r = requests.findById(in.requestId()).orElseThrow(() -> notFound("Request"));
        if (r.getStatus() != Enums.Status.RESOLVED && r.getStatus() != Enums.Status.CLOSED) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Feedback can only be submitted for resolved requests");
        }
        if (feedbacks.existsByRequestId(in.requestId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Feedback already submitted");
        }
        if (in.rating() < 1 || in.rating() > 5) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Rating must be 1-5");
        }
        User student = users.findById(in.studentId()).orElseThrow(() -> notFound("User"));
        Feedback fb = new Feedback();
        fb.setRequest(r); fb.setStudent(student);
        fb.setRating(in.rating()); fb.setComments(in.comments());
        return feedbacks.save(fb);
    }

    public Optional<Feedback> getFeedback(Long requestId) {
        return feedbacks.findByRequestId(requestId);
    }

    // ──────────────────────────── Stats & Analytics ────────────────────────────
    public Map<String, Object> stats() {
        Map<String, Object> m = new LinkedHashMap<>();
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (Enums.Status s : Enums.Status.values()) byStatus.put(s.name(), 0L);
        for (Object[] row : requests.countByStatus()) byStatus.put(row[0].toString(), (Long) row[1]);

        Map<String, Long> byCat = new LinkedHashMap<>();
        for (Object[] row : requests.countByCategory()) byCat.put((String) row[0], (Long) row[1]);

        // Overdue = unresolved older than 72 hours
        LocalDateTime threshold = LocalDateTime.now().minusHours(72);
        long overdueCount = requests.findOverdue(threshold).size();

        m.put("total", requests.count());
        m.put("byStatus", byStatus);
        m.put("byCategory", byCat);
        m.put("overdueCount", overdueCount);
        return m;
    }

    public List<ServiceRequest> getOverdue() {
        return requests.findOverdue(LocalDateTime.now().minusHours(72));
    }

    // ──────────────────────────── History / List ────────────────────────────
    public List<RequestUpdate> history(Long id) {
        return updates.findByRequestIdOrderByCreatedAtAsc(id);
    }

    public List<ServiceRequest> listForTechnician(Long techId) {
        return requests.findByAssignedTechnicianIdOrderByCreatedAtDesc(techId);
    }

    // ──────────────────────────── Internal ────────────────────────────
    private void log(ServiceRequest r, Enums.Status s, String comment, User by) {
        RequestUpdate u = new RequestUpdate();
        u.setRequest(r); u.setStatus(s); u.setComment(comment); u.setUpdatedBy(by);
        updates.save(u);
    }

    private ResponseStatusException notFound(String what) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, what + " not found");
    }
}
