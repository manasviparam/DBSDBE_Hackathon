import { useState, useEffect, useCallback, useRef } from 'react'
import { api, auth } from './api'

// ─────────────────────────────────────────────────────────────────────────────
// Utilities
// ─────────────────────────────────────────────────────────────────────────────
function Badge({ value, type = 'status' }) {
  const cls = type === 'role' ? `badge badge-${value}` : `badge badge-${value}`
  return <span className={cls}>{value?.replace(/_/g, ' ')}</span>
}

function Spinner() {
  return <div className="spinner-wrap"><div className="spinner" /></div>
}

function Alert({ msg, type = 'error' }) {
  if (!msg) return null
  return <div className={`alert alert-${type}`}>{msg}</div>
}

function Stars({ value, onChange }) {
  return (
    <div className="stars">
      {[1, 2, 3, 4, 5].map(n => (
        <span key={n} className={`star${n <= value ? ' filled' : ''}`}
          onClick={() => onChange && onChange(n)}>★</span>
      ))}
    </div>
  )
}

function fmt(dt) {
  if (!dt) return '-'
  return new Date(dt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })
}

function isOverdue(req) {
  if (['RESOLVED', 'CLOSED'].includes(req.status)) return false
  const age = (Date.now() - new Date(req.createdAt)) / 36e5 // hours
  return age > 72
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth Page
// ─────────────────────────────────────────────────────────────────────────────
function AuthPage({ onLogin }) {
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  async function submit(e) {
    e.preventDefault(); setErr(''); setLoading(true)
    try {
      let data
      if (mode === 'register') {
        data = await api.register({ name: form.name, email: form.email, password: form.password })
      } else {
        data = await api.login({ email: form.email, password: form.password })
      }
      auth.save(data)
      onLogin(data)
    } catch (x) { setErr(x.message) }
    finally { setLoading(false) }
  }

  return (
    <div className="auth-page">
      <div className="auth-box">
        <div className="auth-logo">🏫</div>
        <div className="auth-title">CampusCare</div>
        <div className="auth-sub">Smart Campus Service Management</div>
        <Alert msg={err} />
        <form onSubmit={submit}>
          {mode === 'register' && (
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input className="form-control" placeholder="Your full name"
                value={form.name} onChange={set('name')} required />
            </div>
          )}
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <input className="form-control" type="email" placeholder="you@campus.edu"
              value={form.email} onChange={set('email')} required />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-control" type="password" placeholder="••••••••"
              value={form.password} onChange={set('password')} required />
          </div>
          <button className="btn btn-primary btn-full" type="submit" disabled={loading}>
            {loading ? 'Please wait…' : mode === 'login' ? 'Sign In' : 'Create Account'}
          </button>
        </form>
        {mode === 'login' && (
          <div className="auth-switch" style={{marginTop:10,fontSize:12,color:'#94a3b8'}}>
            Demo — Admin: admin@campus.edu / Admin@123
          </div>
        )}
        <div className="auth-switch">
          {mode === 'login'
            ? <>New student? <a onClick={() => setMode('register')}>Register here</a></>
            : <>Already have an account? <a onClick={() => setMode('login')}>Sign in</a></>}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// App Shell (sidebar + topbar)
// ─────────────────────────────────────────────────────────────────────────────
function AppShell({ user, page, setPage, onLogout, children }) {
  const role = user.role
  const navItems = role === 'STUDENT' ? [
    { id: 'my-requests', label: 'My Requests', icon: '📋' },
    { id: 'new-request', label: 'New Request', icon: '➕' },
  ] : role === 'TECHNICIAN' ? [
    { id: 'assigned', label: 'Assigned to Me', icon: '🔧' },
  ] : [
    // Admin / STAFF / DEPT_HEAD
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'all-requests', label: 'All Requests', icon: '📋' },
    { id: 'overdue', label: 'Overdue Alerts', icon: '⚠️' },
    { id: 'categories', label: 'Categories', icon: '🏷️' },
    { id: 'departments', label: 'Departments', icon: '🏢' },
    { id: 'users', label: 'User Management', icon: '👥' },
  ]

  const pageTitle = navItems.find(n => n.id === page)?.label || 'CampusCare'

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand">
          <span className="logo">🏫</span>
          <div><h2>CampusCare</h2><span style={{fontSize:11,color:'#64748b'}}>KL University</span></div>
        </div>
        <div className="sidebar-user">
          <strong>{user.name}</strong>
          <Badge value={user.role} type="role" />
          {user.departmentName && <div style={{marginTop:4,fontSize:11,color:'#64748b'}}>{user.departmentName}</div>}
        </div>
        <nav className="sidebar-nav">
          {navItems.map(n => (
            <div key={n.id} className={`nav-item${page === n.id ? ' active' : ''}`}
              onClick={() => setPage(n.id)}>
              <span className="icon">{n.icon}</span>
              {n.label}
            </div>
          ))}
        </nav>
        <div className="sidebar-footer">
          <button className="logout-btn" onClick={onLogout}>🚪 Logout</button>
        </div>
      </aside>
      <div className="main-content">
        <div className="topbar">
          <h1>{pageTitle}</h1>
          <div className="topbar-right">
            <span style={{fontSize:13,color:'#64748b'}}>👤 {user.name}</span>
          </div>
        </div>
        <div className="page-body">{children}</div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Request History Timeline
// ─────────────────────────────────────────────────────────────────────────────
function RequestTimeline({ requestId }) {
  const [hist, setHist] = useState(null)
  useEffect(() => {
    api.history(requestId).then(setHist).catch(() => setHist([]))
  }, [requestId])

  if (!hist) return <Spinner />
  return (
    <ul className="timeline">
      {hist.map(h => (
        <li key={h.id} className="tl-item">
          <div className="tl-dot">✓</div>
          <div className="tl-content">
            <Badge value={h.status} />
            {h.comment && <span style={{marginLeft:8,fontSize:13}}>{h.comment}</span>}
            <div className="tl-meta">{fmt(h.createdAt)}{h.updatedBy ? ` · ${h.updatedBy.name}` : ''}</div>
          </div>
        </li>
      ))}
      {!hist.length && <li className="text-muted" style={{paddingLeft:14}}>No history yet.</li>}
    </ul>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Request Detail Modal
// ─────────────────────────────────────────────────────────────────────────────
function RequestDetailModal({ req, user, technicians, departments, onClose, onUpdated }) {
  const [tab, setTab] = useState('details')
  const [statusForm, setStatusForm] = useState({ status: req.status, comment: '' })
  const [techId, setTechId] = useState(req.assignedTechnician?.id || '')
  const [deptId, setDeptId] = useState(req.department?.id || '')
  const [feedback, setFeedback] = useState(null)
  const [fbForm, setFbForm] = useState({ rating: 0, comments: '' })
  const [err, setErr] = useState('')
  const [saving, setSaving] = useState(false)
  const isAdmin = ['ADMIN', 'DEPT_HEAD', 'STAFF'].includes(user.role)
  const isTech  = user.role === 'TECHNICIAN'
  const isOwner = req.requester?.id === user.id
  const canFeedback = isOwner && ['RESOLVED','CLOSED'].includes(req.status)

  useEffect(() => {
    if (canFeedback) api.getFeedback(req.id).then(fb => { if (fb) setFeedback(fb) }).catch(() => {})
  }, [req.id, canFeedback])

  async function saveStatus() {
    setSaving(true); setErr('')
    try { await api.setStatus(req.id, { status: statusForm.status, comment: statusForm.comment }); onUpdated() }
    catch(x) { setErr(x.message) } finally { setSaving(false) }
  }

  async function saveTech() {
    if (!techId) return
    setSaving(true); setErr('')
    try { await api.assignTech(req.id, { technicianId: Number(techId) }); onUpdated() }
    catch(x) { setErr(x.message) } finally { setSaving(false) }
  }

  async function saveDept() {
    if (!deptId) return
    setSaving(true); setErr('')
    try { await api.assignDept(req.id, { departmentId: Number(deptId) }); onUpdated() }
    catch(x) { setErr(x.message) } finally { setSaving(false) }
  }

  async function submitFeedback() {
    if (fbForm.rating === 0) { setErr('Please select a rating.'); return }
    setSaving(true); setErr('')
    try {
      const fb = await api.submitFeedback(req.id, { rating: fbForm.rating, comments: fbForm.comments })
      setFeedback(fb); onUpdated()
    } catch(x) { setErr(x.message) } finally { setSaving(false) }
  }

  const loc = [req.building, req.floor && `Floor ${req.floor}`, req.roomNumber && `Room ${req.roomNumber}`, req.location]
    .filter(Boolean).join(', ')

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{maxWidth:620}} onClick={e => e.stopPropagation()}>
        <div className="flex-between mb-2">
          <div className="modal-title" style={{marginBottom:0}}>Request #{req.id} — {req.title}</div>
          <button className="btn btn-ghost btn-sm" onClick={onClose}>✕</button>
        </div>
        <div style={{display:'flex',gap:8,marginBottom:16,borderBottom:'1px solid #e2e8f0',paddingBottom:10}}>
          {['details','timeline',(canFeedback?'feedback':null)].filter(Boolean).map(t=>(
            <button key={t} className={`btn btn-sm ${tab===t?'btn-primary':'btn-ghost'}`}
              onClick={()=>setTab(t)}>{t.charAt(0).toUpperCase()+t.slice(1)}</button>
          ))}
        </div>
        <Alert msg={err} />

        {tab === 'details' && (
          <div>
            <div className="form-row mb-2">
              <div><span className="form-label">Status</span><Badge value={req.status} /></div>
              <div><span className="form-label">Priority</span><Badge value={req.priority} /></div>
              <div><span className="form-label">Category</span><span>{req.category?.name || '—'}{req.aiCategorized?' 🤖':''}</span></div>
            </div>
            <div className="form-group"><span className="form-label">Description</span><p style={{color:'#334155'}}>{req.description}</p></div>
            {loc && <div className="form-group"><span className="form-label">Location</span><p>{loc}</p></div>}
            <div className="form-row mb-2">
              <div><span className="form-label">Requester</span><p>{req.requester?.name}</p></div>
              <div><span className="form-label">Department</span><p>{req.department?.name || '—'}</p></div>
              <div><span className="form-label">Technician</span><p>{req.assignedTechnician?.name || '—'}</p></div>
            </div>
            <div className="form-row">
              <div><span className="form-label">Created</span><p>{fmt(req.createdAt)}</p></div>
              <div><span className="form-label">Updated</span><p>{fmt(req.updatedAt)}</p></div>
            </div>

            {/* Admin controls */}
            {isAdmin && (
              <div style={{marginTop:16,borderTop:'1px solid #f1f5f9',paddingTop:14}}>
                <div className="form-row mb-2">
                  <div>
                    <label className="form-label">Assign Department</label>
                    <div className="flex gap-2">
                      <select className="form-control" value={deptId} onChange={e=>setDeptId(e.target.value)}>
                        <option value="">Select dept…</option>
                        {departments.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}
                      </select>
                      <button className="btn btn-outline btn-sm" onClick={saveDept} disabled={saving}>Assign</button>
                    </div>
                  </div>
                  <div>
                    <label className="form-label">Assign Technician</label>
                    <div className="flex gap-2">
                      <select className="form-control" value={techId} onChange={e=>setTechId(e.target.value)}>
                        <option value="">Select tech…</option>
                        {technicians.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
                      </select>
                      <button className="btn btn-outline btn-sm" onClick={saveTech} disabled={saving}>Assign</button>
                    </div>
                  </div>
                </div>
                <div className="form-row">
                  <div>
                    <label className="form-label">Change Status</label>
                    <select className="form-control" value={statusForm.status}
                      onChange={e=>setStatusForm(f=>({...f,status:e.target.value}))}>
                      {['OPEN','ASSIGNED','IN_PROGRESS','RESOLVED','CLOSED'].map(s=><option key={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="form-label">Remark</label>
                    <input className="form-control" placeholder="Optional remark"
                      value={statusForm.comment} onChange={e=>setStatusForm(f=>({...f,comment:e.target.value}))} />
                  </div>
                </div>
                <button className="btn btn-primary btn-sm" style={{marginTop:8}} onClick={saveStatus} disabled={saving}>
                  Update Status
                </button>
              </div>
            )}

            {/* Technician controls */}
            {isTech && (
              <div style={{marginTop:16,borderTop:'1px solid #f1f5f9',paddingTop:14}}>
                <div className="form-row">
                  <div>
                    <label className="form-label">Update Status</label>
                    <select className="form-control" value={statusForm.status}
                      onChange={e=>setStatusForm(f=>({...f,status:e.target.value}))}>
                      {['IN_PROGRESS','RESOLVED'].map(s=><option key={s}>{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="form-label">Resolution Remark</label>
                    <input className="form-control" placeholder="Describe what was done"
                      value={statusForm.comment} onChange={e=>setStatusForm(f=>({...f,comment:e.target.value}))} />
                  </div>
                </div>
                <button className="btn btn-success btn-sm" style={{marginTop:8}} onClick={saveStatus} disabled={saving}>
                  Update
                </button>
              </div>
            )}
          </div>
        )}

        {tab === 'timeline' && <RequestTimeline requestId={req.id} />}

        {tab === 'feedback' && (
          <div>
            {feedback ? (
              <div>
                <div className="alert alert-success">Feedback submitted — Thank you!</div>
                <Stars value={feedback.rating} />
                <p style={{marginTop:8,color:'#334155'}}>{feedback.comments || '(No comments)'}</p>
              </div>
            ) : (
              <div>
                <div className="form-group">
                  <label className="form-label">Rate the resolution</label>
                  <Stars value={fbForm.rating} onChange={r=>setFbForm(f=>({...f,rating:r}))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Comments (optional)</label>
                  <textarea className="form-control" rows="3" placeholder="Share your experience…"
                    value={fbForm.comments} onChange={e=>setFbForm(f=>({...f,comments:e.target.value}))} />
                </div>
                <button className="btn btn-primary" onClick={submitFeedback} disabled={saving}>Submit Feedback</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Request Table (shared)
// ─────────────────────────────────────────────────────────────────────────────
function RequestTable({ rows, user, technicians, departments, onUpdated, showRequester = false }) {
  const [selected, setSelected] = useState(null)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [filterPriority, setFilterPriority] = useState('')

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    const matchQ = !q || r.title.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) ||
      (r.requester?.name?.toLowerCase().includes(q))
    const matchS = !filterStatus || r.status === filterStatus
    const matchP = !filterPriority || r.priority === filterPriority
    return matchQ && matchS && matchP
  })

  return (
    <>
      <div className="toolbar">
        <input className="form-control search-input" placeholder="🔍 Search requests…"
          value={search} onChange={e=>setSearch(e.target.value)} />
        <select className="form-control filter-select" value={filterStatus} onChange={e=>setFilterStatus(e.target.value)}>
          <option value="">All Statuses</option>
          {['OPEN','ASSIGNED','IN_PROGRESS','RESOLVED','CLOSED'].map(s=><option key={s}>{s}</option>)}
        </select>
        <select className="form-control filter-select" value={filterPriority} onChange={e=>setFilterPriority(e.target.value)}>
          <option value="">All Priorities</option>
          {['HIGH','MEDIUM','LOW'].map(p=><option key={p}>{p}</option>)}
        </select>
        <span className="text-muted">{filtered.length} result{filtered.length!==1?'s':''}</span>
      </div>
      <div className="card" style={{padding:0}}>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Title</th>
                {showRequester && <th>Requester</th>}
                <th>Category</th>
                <th>Location</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => (
                <tr key={r.id} className={`clickable${isOverdue(r)?' overdue-row':''}`}
                  onClick={()=>setSelected(r)}>
                  <td>{r.id}</td>
                  <td>
                    <div style={{fontWeight:500}}>{r.title}</div>
                    {r.assignedTechnician && <div className="text-muted">🔧 {r.assignedTechnician.name}</div>}
                    {r.department && <div className="text-muted">🏢 {r.department.name}</div>}
                  </td>
                  {showRequester && <td>{r.requester?.name}</td>}
                  <td>{r.category?.name || '—'}{r.aiCategorized ? ' 🤖' : ''}</td>
                  <td>
                    {[r.building, r.floor && `F${r.floor}`, r.roomNumber && `R${r.roomNumber}`]
                      .filter(Boolean).join(' · ') || r.location || '—'}
                  </td>
                  <td><Badge value={r.priority} /></td>
                  <td>
                    <Badge value={r.status} />
                    {isOverdue(r) && <div className="badge badge-overdue" style={{marginTop:3}}>OVERDUE</div>}
                  </td>
                  <td>{fmt(r.createdAt)}</td>
                </tr>
              ))}
              {!filtered.length && <tr><td colSpan="8" className="empty-row">No requests found.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
      {selected && (
        <RequestDetailModal req={selected} user={user}
          technicians={technicians} departments={departments}
          onClose={()=>setSelected(null)}
          onUpdated={()=>{ onUpdated(); setSelected(null) }} />
      )}
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// New Request Form (Student)
// ─────────────────────────────────────────────────────────────────────────────
const BUILDINGS = ['Block A', 'Block B', 'Block C', 'Block D', 'Block E',
  'Library', 'Admin Block', 'Hostel 1', 'Hostel 2', 'Cafeteria', 'Sports Complex']
const FLOORS = ['Ground', '1st', '2nd', '3rd', '4th', '5th']

function NewRequestPage({ user, categories, onDone }) {
  const [form, setForm] = useState({
    title: '', description: '', building: '', floor: '', roomNumber: '',
    priority: 'MEDIUM', categoryId: ''
  })
  const [hint, setHint] = useState('')
  const [err, setErr] = useState('')
  const [saving, setSaving] = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  async function suggest() {
    try {
      const r = await api.suggestCat(form.title + ' ' + form.description)
      setHint(r.category ? `💡 Suggested category: ${r.category}` : 'No suggestion (try more detail)')
    } catch { setHint('Could not suggest') }
  }

  async function submit(e) {
    e.preventDefault(); setErr(''); setSaving(true)
    try {
      await api.createRequest({
        userId: user.id,
        title: form.title,
        description: form.description,
        location: [form.building, form.floor, form.roomNumber].filter(Boolean).join(', '),
        building: form.building,
        floor: form.floor,
        roomNumber: form.roomNumber,
        priority: form.priority,
        categoryId: form.categoryId ? Number(form.categoryId) : null
      })
      onDone()
    } catch (x) { setErr(x.message) }
    finally { setSaving(false) }
  }

  return (
    <div className="card" style={{maxWidth:700}}>
      <div className="card-title">🛠️ Report a Campus Issue</div>
      <Alert msg={err} />
      <form onSubmit={submit}>
        <div className="form-group">
          <label className="form-label">Title *</label>
          <input className="form-control" placeholder="Short description of the issue"
            value={form.title} onChange={set('title')} required />
        </div>
        <div className="form-group">
          <label className="form-label">Description *</label>
          <textarea className="form-control" rows="4"
            placeholder="Describe the problem in detail. What happened? Since when?"
            value={form.description} onChange={set('description')} required />
        </div>

        <div className="card-title" style={{marginTop:8}}>📍 Location Details</div>
        <div className="form-row-3">
          <div className="form-group">
            <label className="form-label">Building</label>
            <select className="form-control" value={form.building} onChange={set('building')}>
              <option value="">Select building…</option>
              {BUILDINGS.map(b => <option key={b}>{b}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Floor</label>
            <select className="form-control" value={form.floor} onChange={set('floor')}>
              <option value="">Select floor…</option>
              {FLOORS.map(f => <option key={f}>{f}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Room Number</label>
            <input className="form-control" placeholder="e.g. 204, Lab-3"
              value={form.roomNumber} onChange={set('roomNumber')} />
          </div>
        </div>

        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Priority</label>
            <select className="form-control" value={form.priority} onChange={set('priority')}>
              <option value="LOW">Low — cosmetic / non-urgent</option>
              <option value="MEDIUM">Medium — affects daily work</option>
              <option value="HIGH">High — urgent / safety issue</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Category</label>
            <div className="flex gap-2">
              <select className="form-control" value={form.categoryId} onChange={set('categoryId')}>
                <option value="">Auto-detect</option>
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <button type="button" className="btn btn-ghost" style={{whiteSpace:'nowrap'}} onClick={suggest}>🤖 Suggest</button>
            </div>
          </div>
        </div>
        {hint && <div className="alert alert-info">{hint}</div>}

        <div style={{display:'flex',gap:10,marginTop:8}}>
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? 'Submitting…' : '📤 Submit Request'}
          </button>
        </div>
      </form>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin Dashboard
// ─────────────────────────────────────────────────────────────────────────────
function AdminDashboard({ stats, onNav }) {
  if (!stats) return <Spinner />
  const { total, byStatus = {}, byCategory = {}, overdueCount = 0 } = stats
  return (
    <>
      <div className="stats-grid">
        <div className="stat-card"><div className="stat-value">{total}</div><div className="stat-label">Total Requests</div></div>
        <div className="stat-card green"><div className="stat-value">{byStatus.OPEN || 0}</div><div className="stat-label">Open</div></div>
        <div className="stat-card orange"><div className="stat-value">{(byStatus.ASSIGNED||0)+(byStatus.IN_PROGRESS||0)}</div><div className="stat-label">In Progress</div></div>
        <div className="stat-card"><div className="stat-value">{byStatus.RESOLVED || 0}</div><div className="stat-label">Resolved</div></div>
        <div className="stat-card red"><div className="stat-value">{overdueCount}</div><div className="stat-label">Overdue (&gt;72h)</div></div>
      </div>
      <div className="form-row">
        <div className="card">
          <div className="card-title">By Status</div>
          {Object.entries(byStatus).map(([k,v]) => (
            <div key={k} className="flex-between" style={{padding:'6px 0',borderBottom:'1px solid #f1f5f9'}}>
              <Badge value={k} />
              <strong>{v}</strong>
            </div>
          ))}
        </div>
        <div className="card">
          <div className="card-title">By Category</div>
          {Object.entries(byCategory).length ? Object.entries(byCategory).map(([k,v]) => (
            <div key={k} className="flex-between" style={{padding:'6px 0',borderBottom:'1px solid #f1f5f9'}}>
              <span>{k}</span><strong>{v}</strong>
            </div>
          )) : <p className="text-muted">No categorized requests yet.</p>}
        </div>
      </div>
      {overdueCount > 0 && (
        <div className="alert alert-warning" style={{cursor:'pointer'}} onClick={()=>onNav('overdue')}>
          ⚠️ {overdueCount} request{overdueCount>1?'s are':' is'} overdue (unresolved &gt; 72h). Click to view.
        </div>
      )}
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// User Management Page (Admin)
// ─────────────────────────────────────────────────────────────────────────────
function UserManagementPage({ departments }) {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name:'', email:'', password:'', role:'TECHNICIAN', departmentId:'' })
  const [err, setErr] = useState('')

  const load = () => api.listUsers().then(setUsers).finally(()=>setLoading(false))
  useEffect(()=>{ load() },[])
  const set = k => e => setForm(f=>({...f,[k]:e.target.value}))

  async function create(e) {
    e.preventDefault(); setErr('')
    try {
      await api.createUser({ ...form, departmentId: form.departmentId ? Number(form.departmentId) : null })
      setShowModal(false); setForm({ name:'', email:'', password:'', role:'TECHNICIAN', departmentId:'' })
      load()
    } catch(x) { setErr(x.message) }
  }

  async function del(id, name) {
    if (!confirm(`Delete user "${name}"?`)) return
    try { await api.deleteUser(id); load() } catch(x) { alert(x.message) }
  }

  if (loading) return <Spinner />
  return (
    <>
      <div className="flex-between mb-2">
        <span className="text-muted">{users.length} user{users.length!==1?'s':''}</span>
        <button className="btn btn-primary" onClick={()=>setShowModal(true)}>➕ Add Staff/Technician</button>
      </div>
      <div className="card" style={{padding:0}}>
        <div className="table-wrap">
          <table>
            <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Actions</th></tr></thead>
            <tbody>
              {users.map(u=>(
                <tr key={u.id}>
                  <td>{u.id}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td><Badge value={u.role} type="role" /></td>
                  <td>{u.department?.name || '—'}</td>
                  <td><button className="btn btn-danger btn-sm" onClick={()=>del(u.id,u.name)}>Delete</button></td>
                </tr>
              ))}
              {!users.length && <tr><td colSpan="6" className="empty-row">No users found.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={()=>setShowModal(false)}>
          <div className="modal" onClick={e=>e.stopPropagation()}>
            <div className="modal-title">Add Staff / Technician</div>
            <Alert msg={err} />
            <form onSubmit={create}>
              <div className="form-group"><label className="form-label">Full Name</label>
                <input className="form-control" value={form.name} onChange={set('name')} required /></div>
              <div className="form-group"><label className="form-label">Email</label>
                <input className="form-control" type="email" value={form.email} onChange={set('email')} required /></div>
              <div className="form-group"><label className="form-label">Password</label>
                <input className="form-control" type="password" value={form.password} onChange={set('password')} required /></div>
              <div className="form-row">
                <div className="form-group"><label className="form-label">Role</label>
                  <select className="form-control" value={form.role} onChange={set('role')}>
                    <option value="TECHNICIAN">Technician</option>
                    <option value="STAFF">Staff</option>
                    <option value="DEPT_HEAD">Dept Head</option>
                    <option value="ADMIN">Admin</option>
                  </select></div>
                <div className="form-group"><label className="form-label">Department</label>
                  <select className="form-control" value={form.departmentId} onChange={set('departmentId')}>
                    <option value="">None</option>
                    {departments.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}
                  </select></div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline" onClick={()=>setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Categories/Departments management (Admin)
// ─────────────────────────────────────────────────────────────────────────────
function CategoriesPage({ departments, onReload }) {
  const [cats, setCats] = useState([])
  const [form, setForm] = useState({ name:'', defaultDepartmentId:'' })
  const [err, setErr] = useState('')
  const load = () => api.categories().then(setCats)
  useEffect(()=>{ load() },[])
  const set = k => e => setForm(f=>({...f,[k]:e.target.value}))
  async function create(e) {
    e.preventDefault(); setErr('')
    try {
      await api.createCategory({ name:form.name, defaultDepartmentId: form.defaultDepartmentId||null })
      setForm({ name:'', defaultDepartmentId:'' }); load()
    } catch(x) { setErr(x.message) }
  }
  async function del(id) {
    if (!confirm('Delete this category?')) return
    try { await api.deleteCategory(id); load() } catch(x) { alert(x.message) }
  }
  return (
    <div className="form-row" style={{alignItems:'flex-start'}}>
      <div className="card">
        <div className="card-title">Existing Categories</div>
        {cats.map(c=>(
          <div key={c.id} className="flex-between" style={{padding:'6px 0',borderBottom:'1px solid #f1f5f9'}}>
            <span>{c.name} {c.defaultDepartment && <span className="text-muted">→ {c.defaultDepartment.name}</span>}</span>
            <button className="btn btn-danger btn-sm" onClick={()=>del(c.id)}>✕</button>
          </div>
        ))}
      </div>
      <div className="card">
        <div className="card-title">Add Category</div>
        <Alert msg={err} />
        <form onSubmit={create}>
          <div className="form-group"><label className="form-label">Name</label>
            <input className="form-control" value={form.name} onChange={set('name')} required /></div>
          <div className="form-group"><label className="form-label">Default Department</label>
            <select className="form-control" value={form.defaultDepartmentId} onChange={set('defaultDepartmentId')}>
              <option value="">None</option>
              {departments.map(d=><option key={d.id} value={d.id}>{d.name}</option>)}
            </select></div>
          <button className="btn btn-primary" type="submit">Add</button>
        </form>
      </div>
    </div>
  )
}

function DepartmentsPage() {
  const [depts, setDepts] = useState([])
  const [form, setForm] = useState({ name:'' })
  const [err, setErr] = useState('')
  const load = () => api.departments().then(setDepts)
  useEffect(()=>{ load() },[])
  async function create(e) {
    e.preventDefault(); setErr('')
    try { await api.createDept({ name:form.name }); setForm({name:''}); load() }
    catch(x) { setErr(x.message) }
  }
  async function del(id) {
    if (!confirm('Delete department?')) return
    try { await api.deleteDept(id); load() } catch(x) { alert(x.message) }
  }
  return (
    <div className="form-row" style={{alignItems:'flex-start'}}>
      <div className="card">
        <div className="card-title">Existing Departments</div>
        {depts.map(d=>(
          <div key={d.id} className="flex-between" style={{padding:'6px 0',borderBottom:'1px solid #f1f5f9'}}>
            <span>{d.name}</span>
            <button className="btn btn-danger btn-sm" onClick={()=>del(d.id)}>✕</button>
          </div>
        ))}
      </div>
      <div className="card" style={{maxWidth:300}}>
        <div className="card-title">Add Department</div>
        <Alert msg={err} />
        <form onSubmit={create}>
          <div className="form-group"><label className="form-label">Name</label>
            <input className="form-control" value={form.name} onChange={e=>setForm({name:e.target.value})} required /></div>
          <button className="btn btn-primary" type="submit">Add</button>
        </form>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Chatbot Widget
// ─────────────────────────────────────────────────────────────────────────────
const QUICK_FAQS = [
  'How do I raise a complaint?',
  'How do I track my request?',
  'How long does resolution take?',
  'How to report Wi-Fi problems?',
]

function ChatbotWidget() {
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState([
    { from: 'bot', text: '👋 Hi! I\'m the CampusCare assistant. Ask me anything about campus services!' }
  ])
  const [input, setInput] = useState('')
  const bottomRef = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  async function ask(q) {
    const query = q || input.trim()
    if (!query) return
    setInput('')
    setMessages(m => [...m, { from: 'user', text: query }])
    try {
      const r = await api.chatbotAsk(query)
      setMessages(m => [...m, { from: 'bot', text: r.answer }])
    } catch {
      setMessages(m => [...m, { from: 'bot', text: 'Sorry, I could not connect to the server. Please try again.' }])
    }
  }

  return (
    <>
      <button className="chat-fab" onClick={() => setOpen(o => !o)} title="Ask CampusCare Assistant">
        {open ? '✕' : '💬'}
      </button>
      {open && (
        <div className="chat-window">
          <div className="chat-header">
            <h4>🤖 CampusCare Assistant</h4>
            <button style={{background:'none',border:'none',color:'#fff',cursor:'pointer'}} onClick={()=>setOpen(false)}>✕</button>
          </div>
          <div className="chat-messages">
            {messages.map((m, i) => (
              <div key={i} className={`msg msg-${m.from}`}>{m.text}</div>
            ))}
            <div ref={bottomRef} />
          </div>
          <div className="faq-chips">
            {QUICK_FAQS.map(q => <button key={q} className="faq-chip" onClick={()=>ask(q)}>{q}</button>)}
          </div>
          <div className="chat-input">
            <input className="form-control" placeholder="Ask a question…"
              value={input} onChange={e=>setInput(e.target.value)}
              onKeyDown={e=>e.key==='Enter' && ask()} />
            <button className="btn btn-primary btn-sm" onClick={()=>ask()}>Send</button>
          </div>
        </div>
      )}
    </>
  )
}

// ─────────────────────────────────────────────────────────────────────────────
// Root App
// ─────────────────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(() => auth.user())
  const [page, setPage] = useState(null)
  const [requests, setRequests] = useState([])
  const [categories, setCategories] = useState([])
  const [departments, setDepartments] = useState([])
  const [technicians, setTechnicians] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(false)

  const isAdmin = user && ['ADMIN','DEPT_HEAD','STAFF'].includes(user.role)
  const isTech  = user && user.role === 'TECHNICIAN'

  // Default page per role
  useEffect(() => {
    if (!user) return
    if (isAdmin)      setPage('dashboard')
    else if (isTech)  setPage('assigned')
    else              setPage('my-requests')
  }, [user?.role])

  const loadData = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const [cats, depts] = await Promise.all([api.categories(), api.departments()])
      setCategories(cats); setDepartments(depts)
      if (isAdmin) {
        const [reqs, st, techs] = await Promise.all([api.listRequests(), api.stats(), api.listTechs()])
        setRequests(reqs); setStats(st); setTechnicians(techs)
      } else if (isTech) {
        const reqs = await api.listRequests()
        setRequests(reqs)
      } else {
        const reqs = await api.listRequests({ userId: user.id })
        setRequests(reqs)
      }
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }, [user?.id, user?.role])

  useEffect(() => { loadData() }, [loadData])

  function handleLogin(data) { auth.save(data); setUser(data) }
  function handleLogout() { auth.clear(); setUser(null); setPage(null) }

  if (!user) return <AuthPage onLogin={handleLogin} />

  function renderPage() {
    if (loading && !requests.length) return <Spinner />

    if (isAdmin) {
      if (page === 'dashboard')   return <AdminDashboard stats={stats} onNav={setPage} />
      if (page === 'all-requests') return (
        <RequestTable rows={requests} user={user} technicians={technicians}
          departments={departments} onUpdated={loadData} showRequester />
      )
      if (page === 'overdue') {
        const now = Date.now()
        const over = requests.filter(r => !['RESOLVED','CLOSED'].includes(r.status)
          && (now - new Date(r.createdAt))/36e5 > 72)
        return (
          <>
            <div className="alert alert-warning" style={{marginBottom:16}}>
              ⚠️ Showing {over.length} overdue request{over.length!==1?'s':''} (unresolved &gt; 72 hours)
            </div>
            <RequestTable rows={over} user={user} technicians={technicians}
              departments={departments} onUpdated={loadData} showRequester />
          </>
        )
      }
      if (page === 'categories')  return <CategoriesPage departments={departments} onReload={loadData} />
      if (page === 'departments') return <DepartmentsPage />
      if (page === 'users')       return <UserManagementPage departments={departments} />
    }

    if (isTech) {
      return (
        <>
          <div className="stats-grid" style={{gridTemplateColumns:'repeat(3,1fr)'}}>
            <div className="stat-card"><div className="stat-value">{requests.length}</div><div className="stat-label">Assigned</div></div>
            <div className="stat-card orange"><div className="stat-value">{requests.filter(r=>r.status==='IN_PROGRESS').length}</div><div className="stat-label">In Progress</div></div>
            <div className="stat-card green"><div className="stat-value">{requests.filter(r=>r.status==='RESOLVED').length}</div><div className="stat-label">Resolved</div></div>
          </div>
          <RequestTable rows={requests} user={user} technicians={[]} departments={[]}
            onUpdated={loadData} showRequester />
        </>
      )
    }

    // Student
    if (page === 'new-request') return (
      <NewRequestPage user={user} categories={categories} onDone={()=>{ loadData(); setPage('my-requests') }} />
    )
    return (
      <>
        <div className="stats-grid" style={{gridTemplateColumns:'repeat(4,1fr)'}}>
          <div className="stat-card"><div className="stat-value">{requests.length}</div><div className="stat-label">Total</div></div>
          <div className="stat-card green"><div className="stat-value">{requests.filter(r=>r.status==='OPEN').length}</div><div className="stat-label">Open</div></div>
          <div className="stat-card orange"><div className="stat-value">{requests.filter(r=>['ASSIGNED','IN_PROGRESS'].includes(r.status)).length}</div><div className="stat-label">In Progress</div></div>
          <div className="stat-card purple"><div className="stat-value">{requests.filter(r=>r.status==='RESOLVED').length}</div><div className="stat-label">Resolved</div></div>
        </div>
        <div className="flex-between mb-2">
          <span />
          <button className="btn btn-primary" onClick={()=>setPage('new-request')}>➕ New Request</button>
        </div>
        <RequestTable rows={requests} user={user} technicians={[]} departments={[]}
          onUpdated={loadData} showRequester={false} />
      </>
    )
  }

  return (
    <AppShell user={user} page={page} setPage={setPage} onLogout={handleLogout}>
      {renderPage()}
      <ChatbotWidget />
    </AppShell>
  )
}
