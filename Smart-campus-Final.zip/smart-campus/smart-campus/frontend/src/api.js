// ── Token helpers ──────────────────────────────────────────────────
const TOKEN_KEY = 'cc_token';
const USER_KEY  = 'cc_user';

export const auth = {
  save: (data) => {
    localStorage.setItem(TOKEN_KEY, data.token);
    localStorage.setItem(USER_KEY, JSON.stringify(data));
  },
  clear: () => { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); },
  token: () => localStorage.getItem(TOKEN_KEY),
  user:  () => { try { return JSON.parse(localStorage.getItem(USER_KEY)); } catch { return null; } },
};

// ── HTTP helper ────────────────────────────────────────────────────
async function call(method, url, body) {
  const headers = { 'Content-Type': 'application/json' };
  const token = auth.token();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(url, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return null;

  let data;
  try { data = await res.json(); } catch { data = null; }

  if (!res.ok) {
    const msg = data?.message || data?.error || res.statusText || 'Request failed';
    throw new Error(msg);
  }
  return data;
}

// ── API surface ────────────────────────────────────────────────────
export const api = {
  // Auth
  login:    (b)       => call('POST', '/api/auth/login', b),
  register: (b)       => call('POST', '/api/auth/register', b),
  me:       ()        => call('GET',  '/api/auth/me'),

  // Lookups
  categories:  ()     => call('GET',  '/api/categories'),
  departments: ()     => call('GET',  '/api/departments'),

  // Requests
  createRequest: (b)  => call('POST', '/api/requests', b),
  listRequests:  (params = {}) => {
    const q = new URLSearchParams();
    if (params.userId) q.set('userId', params.userId);
    if (params.techId) q.set('techId', params.techId);
    return call('GET', '/api/requests' + (q.toString() ? '?' + q : ''));
  },
  getRequest:    (id) => call('GET',  `/api/requests/${id}`),
  history:       (id) => call('GET',  `/api/requests/${id}/history`),
  setStatus:     (id, b) => call('PUT', `/api/requests/${id}/status`, b),
  assignDept:    (id, b) => call('PUT', `/api/requests/${id}/assign-department`, b),
  assignTech:    (id, b) => call('PUT', `/api/requests/${id}/assign-technician`, b),
  suggestCat:    (text)  => call('POST', '/api/requests/suggest-category', { text }),

  // Feedback
  submitFeedback: (id, b)  => call('POST', `/api/requests/${id}/feedback`, b),
  getFeedback:    (id)     => call('GET',  `/api/requests/${id}/feedback`),

  // Admin
  stats:    ()        => call('GET', '/api/admin/stats'),
  overdue:  ()        => call('GET', '/api/admin/overdue'),

  // Admin – categories/departments CRUD
  createCategory:  (b)    => call('POST',   '/api/admin/categories', b),
  updateCategory:  (id,b) => call('PUT',    `/api/admin/categories/${id}`, b),
  deleteCategory:  (id)   => call('DELETE', `/api/admin/categories/${id}`),
  createDept:      (b)    => call('POST',   '/api/admin/departments', b),
  deleteDept:      (id)   => call('DELETE', `/api/admin/departments/${id}`),

  // User management
  listUsers:      ()      => call('GET',    '/api/users'),
  listTechs:      ()      => call('GET',    '/api/users/technicians'),
  createUser:     (b)     => call('POST',   '/api/users', b),
  updateUser:     (id,b)  => call('PUT',    `/api/users/${id}`, b),
  deleteUser:     (id)    => call('DELETE', `/api/users/${id}`),

  // Chatbot
  chatbotAsk:  (q)    => call('GET', `/api/chatbot/ask?q=${encodeURIComponent(q)}`),
  chatbotFaqs: ()     => call('GET', '/api/chatbot/faqs'),
};
