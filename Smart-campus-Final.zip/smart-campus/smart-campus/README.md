# CampusCare – Smart Campus Service Management System
**KL University CODESPARK Hackathon**

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite |
| Backend | Java 17 + Spring Boot 3.3.5 |
| Database | MySQL 8 |
| ORM | Spring Data JPA / Hibernate |
| Security | Spring Security + JWT (jjwt 0.12.6) |
| Build | Maven |

---

## Demo Accounts

| Role | Email | Password |
|---|---|---|
| Admin | admin@campus.edu | Admin@123 |
| Technician | tech@campus.edu | Tech@123 |
| Student | student@campus.edu | Student@123 |

---

## Quick Start

### Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8+
- Node.js 18+ with npm/pnpm

### 1. Database Setup

```bash
# Log in to MySQL and run the schema + seed scripts
mysql -u root -p < database/schema.sql
mysql -u root -p smart_campus < database/seed.sql
```

### 2. Backend Setup

```bash
cd backend

# Copy and edit environment config
cp .env.example .env
# Edit .env: set DB_PASS and optionally JWT_SECRET

# Run the Spring Boot application
# Option A – Maven wrapper (if present)
./mvnw spring-boot:run

# Option B – System Maven
mvn spring-boot:run

# Option C – Set env vars inline (Windows PowerShell)
$env:DB_PASS="yourpassword"; mvn spring-boot:run
```

The backend starts at **http://localhost:8080**

### 3. Frontend Setup

```bash
cd frontend
npm install          # or: pnpm install
npm run dev          # starts at http://localhost:5173
```

The Vite dev server proxies `/api/*` to `http://localhost:8080`.

---

## Environment Variables (Backend)

| Variable | Default | Description |
|---|---|---|
| `DB_URL` | `jdbc:mysql://localhost:3307/smart_campus?...` | MySQL JDBC URL |
| `DB_USER` | `root` | MySQL username |
| `DB_PASS` | *(required)* | MySQL password |
| `JWT_SECRET` | see `.env.example` | JWT signing secret (change in prod!) |
| `ADMIN_EMAIL` | `admin@campus.edu` | Default admin email |
| `ADMIN_PASSWORD` | `Admin@123` | Default admin password |

---

## API Endpoints

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | /api/auth/register | Student self-registration |
| POST | /api/auth/login | Login → returns JWT token |
| GET | /api/auth/me | Get current user profile |

### Requests
| Method | Endpoint | Access |
|---|---|---|
| POST | /api/requests | Create request |
| GET | /api/requests | List (filtered by role) |
| GET | /api/requests/{id} | Get single request |
| GET | /api/requests/{id}/history | Request timeline |
| PUT | /api/requests/{id}/status | Change status |
| PUT | /api/requests/{id}/assign-department | Assign department (admin) |
| PUT | /api/requests/{id}/assign-technician | Assign technician (admin) |
| POST | /api/requests/suggest-category | AI category suggestion |
| POST | /api/requests/{id}/feedback | Submit feedback |
| GET | /api/requests/{id}/feedback | Get feedback |

### Admin
| Method | Endpoint | Description |
|---|---|---|
| GET | /api/admin/stats | Dashboard analytics |
| GET | /api/admin/overdue | Overdue requests (>72h) |
| POST/PUT/DELETE | /api/admin/categories | Category CRUD |
| POST/PUT/DELETE | /api/admin/departments | Department CRUD |

### Users
| Method | Endpoint | Description |
|---|---|---|
| GET | /api/users | List all users |
| GET | /api/users/technicians | List technicians |
| POST | /api/users | Create staff/technician |
| PUT | /api/users/{id} | Update user |
| DELETE | /api/users/{id} | Delete user |

### Chatbot
| Method | Endpoint | Description |
|---|---|---|
| GET | /api/chatbot/ask?q=... | Query FAQ bot |
| GET | /api/chatbot/faqs | List all FAQs |

---

## Features

### ✅ Implemented
- JWT-based authentication with BCrypt password hashing
- Role-based access: STUDENT / TECHNICIAN / STAFF / DEPT_HEAD / ADMIN
- Student: submit requests with building/floor/room, track status, view history, submit feedback
- Technician: view assigned requests, update status, add resolution remarks
- Admin: dashboard with analytics, assign requests to departments & technicians, manage categories/departments/users
- Request workflow: Open → Assigned → In Progress → Resolved → Closed
- Full request history/timeline for every status change
- Automatic category suggestion (keyword-based AI classifier)
- Overdue alert system (flags requests unresolved > 72 hours)
- Smart FAQ Chatbot (keyword-scored matching)
- Responsive sidebar layout with separate dashboards per role
- Search and filter on all request tables
- Star-rating feedback system

### Request Workflow
```
OPEN → ASSIGNED → IN_PROGRESS → RESOLVED → CLOSED
```

### Unique Features (Phase 3)
- **🤖 Smart FAQ Chatbot** – Keyword-scored bot answering 7 common campus questions; extendable to ML
- **📍 Campus Location Picker** – Building / Floor / Room dropdowns on every request
- **🏷️ Auto Category Classification** – Java keyword scorer suggests category on description input
- **⚠️ Overdue Alerts** – Admin dashboard highlights and counts requests older than 72 h
- **⭐ Resolution Feedback** – Star rating + comments after request is resolved

---

## Project Structure

```
smart-campus/
├── backend/
│   ├── pom.xml
│   ├── .env.example
│   └── src/main/java/com/campus/smartcampus/
│       ├── SmartCampusApplication.java
│       ├── config/         AppConfig, SecurityConfig
│       ├── model/          User, ServiceRequest, Category, Department,
│       │                   RequestUpdate, Feedback, ChatbotFaq, Enums
│       ├── repo/           Repos (all JPA interfaces)
│       ├── security/       JwtUtil, JwtFilter
│       ├── service/        RequestService, ClassifierService
│       └── web/            AuthController, RequestController,
│                           AdminController, UserController, ChatbotController
├── frontend/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       ├── App.jsx         (all UI components)
│       ├── api.js          (JWT-aware HTTP client)
│       └── styles.css
├── database/
│   ├── schema.sql
│   ├── seed.sql
│   └── useful_queries.sql
└── README.md
```

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│                   Browser (React 18)                │
│  Auth → Student Dashboard                           │
│       → Admin Dashboard (Stats, Assign, Manage)     │
│       → Technician Dashboard (Assigned requests)    │
│       → Chatbot Widget                              │
└────────────────────┬────────────────────────────────┘
                     │ HTTPS / JWT Bearer Token
                     │ /api/**
┌────────────────────▼────────────────────────────────┐
│         Spring Boot 3 Backend (:8080)               │
│  Spring Security + JWT Filter                       │
│  Controllers → Services → Repositories (JPA)        │
│  BCrypt · ClassifierService · ChatbotFaqRepo        │
└────────────────────┬────────────────────────────────┘
                     │ JDBC (MySQL Connector J)
┌────────────────────▼────────────────────────────────┐
│              MySQL 8 Database                       │
│  users · departments · categories                   │
│  service_requests · request_updates                 │
│  feedback · chatbot_faqs                            │
└─────────────────────────────────────────────────────┘
```

---

## Known Limitations / Next Steps
- Pagination not yet implemented on request lists (acceptable for demo scale)
- Email notifications not implemented (can add Spring Mail)
- Interactive Leaflet map is a stretch goal (location picker uses dropdowns instead)
- Python ML classifier is an optional Phase 3+ extension of ClassifierService

---

*CampusCare · KL University CODESPARK Hackathon · Built with Spring Boot + React*
